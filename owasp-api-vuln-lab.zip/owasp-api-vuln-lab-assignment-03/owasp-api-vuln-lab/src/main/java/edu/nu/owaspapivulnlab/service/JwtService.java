package edu.nu.owaspapivulnlab.service;

import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import jakarta.annotation.PostConstruct;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.crypto.SecretKey;
import java.nio.charset.StandardCharsets;
import java.util.Date;

/**
 * Task 7: JWT hardening
 * - Strong secret loaded from env/property (>=32 chars)  -> SECURITY_JWT_SECRET or security.jwt.secret
 * - Short TTL (default 15m; configurable via SECURITY_JWT_TTLSECONDS)
 * - Explicit issuer & audience; both required
 * - Strict validation: signature, issuer, audience, expiry; zero clock skew
 */
@Service
public class JwtService {

    // Values come from env or application.properties (Spring maps ENV SECURITY_JWT_SECRET -> security.jwt.secret)
    private final String secretString;
    private final String issuer;
    private final String audience;
    private final long ttlSeconds;

    private SecretKey key;
    private JwtParser parser;

    public JwtService(
            @Value("${security.jwt.secret:}") String secretString,
            @Value("${security.jwt.issuer:apilab}") String issuer,
            @Value("${security.jwt.audience:apilab-clients}") String audience,
            @Value("${security.jwt.ttlSeconds:900}") long ttlSeconds // 15 minutes default
    ) {
        // ✔ strong secret requirement (prevents weak-key attacks on HS256)
        if (secretString == null || secretString.length() < 32) {
            throw new IllegalStateException(
                    "JWT secret must be at least 32 characters. " +
                    "Set env SECURITY_JWT_SECRET or property security.jwt.secret."
            );
        }
        this.secretString = secretString;
        this.issuer = issuer;
        this.audience = audience;
        this.ttlSeconds = ttlSeconds;
    }

    @PostConstruct
    void init() {
        // Build signing key once
        this.key = Keys.hmacShaKeyFor(secretString.getBytes(StandardCharsets.UTF_8));

        // ✔ strict parser: require issuer/audience, zero clock skew, verify signature with key
        this.parser = Jwts.parserBuilder()
                .requireIssuer(issuer)
                .requireAudience(audience)
                .setSigningKey(key)
                .setAllowedClockSkewSeconds(0) // no tolerance; tokens must be valid to the second
                .build();
    }

    /** Issue compact JWT with subject=username and "role" claim. */
    public String issueToken(String username, String role) {
        Date now = new Date();
        Date exp = new Date(now.getTime() + (ttlSeconds * 1000));

        return Jwts.builder()
                .setSubject(username)
                .setIssuer(issuer)    // ✔ include issuer
                .setAudience(audience)// ✔ include audience
                .claim("role", role)
                .setIssuedAt(now)
                .setExpiration(exp)   // ✔ short TTL enforced
                .signWith(key, SignatureAlgorithm.HS256) // ✔ HS256 with strong secret
                .compact();
    }

    /** Validate token and return subject+role; throws IllegalArgumentException on any failure. */
    public SubjectAndRole validateAndGetSubjectAndRole(String token) {
        try {
            Jws<Claims> jws = parser.parseClaimsJws(token); // ✔ verifies signature, issuer, audience, expiry
            Claims claims = jws.getBody();

            String username = claims.getSubject();
            Object roleObj = claims.get("role");
            String role = (roleObj == null) ? null : String.valueOf(roleObj);

            if (username == null || username.isBlank() || role == null || role.isBlank()) {
                throw new IllegalArgumentException("invalid_or_expired_token");
            }
            return new SubjectAndRole(username, role);
        } catch (JwtException | IllegalArgumentException e) {
            // Any issue (bad sig, wrong iss/aud, expired, malformed) -> invalid
            throw new IllegalArgumentException("invalid_or_expired_token");
        }
    }

    /** Small DTO used by security filter to set Authentication authorities. */
    public record SubjectAndRole(String username, String role) {}
}
