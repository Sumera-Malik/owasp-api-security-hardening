package edu.nu.owaspapivulnlab.web.dto;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;

/**
 * Task 6: Only whitelisted fields for self-service profile updates.
 * - email: optional, must be valid if present
 * - password: optional, must meet length if present
 */
@JsonIgnoreProperties(ignoreUnknown = false)
public class UpdateProfileRequest {

    @Email
    @Size(max = 120)
    private String email;

    @Size(min = 8, max = 128)
    private String password;

    public UpdateProfileRequest() {}

    public String getEmail() { return email; }
    public String getPassword() { return password; }
    public void setEmail(String email) { this.email = email; }
    public void setPassword(String password) { this.password = password; }
}
