package edu.nu.owaspapivulnlab.web.dto;

import jakarta.validation.constraints.NotBlank;

// INLINE: DTO prevents mass-assignment & enables validation
public record LoginRequest(
        @NotBlank String username,
        @NotBlank String password
) {}
