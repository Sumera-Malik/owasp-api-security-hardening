package edu.nu.owaspapivulnlab.web.dto;

import jakarta.validation.constraints.DecimalMin;
import jakarta.validation.constraints.Digits;
import jakarta.validation.constraints.NotNull;

import java.math.BigDecimal;

/**
 * TransferRequest DTO (POJO style with getters/setters).
 *
 * WHY: Our controller must be able to read fromAccountId, toAccountId, and amount.
 * We expose conventional getters so Spring/Jackson can bind JSON -> object, and our code compiles.
 *
 * SECURITY/VALIDATION:
 * - @NotNull on ids and amount
 * - @DecimalMin + @Digits on amount to prevent negative/huge/precision-abuse inputs
 */
public class TransferRequest {

    @NotNull
    private Long fromAccountId;

    @NotNull
    private Long toAccountId;

    @NotNull
    @DecimalMin("0.01")                // <- reject zero/negative amounts
    @Digits(integer = 12, fraction = 2) // <- keep to 2 decimals, cap integer digits
    private BigDecimal amount;

    // --- Getters/Setters (explicit; avoids Lombok dependency surprises) ---

    public Long getFromAccountId() {
        return fromAccountId;
    }

    public void setFromAccountId(Long fromAccountId) {
        this.fromAccountId = fromAccountId;
    }

    public Long getToAccountId() {
        return toAccountId;
    }

    public void setToAccountId(Long toAccountId) {
        this.toAccountId = toAccountId;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
