package edu.nu.owaspapivulnlab;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OwaspApiVulnLabApplication {
    public static void main(String[] args) {
        SpringApplication.run(OwaspApiVulnLabApplication.class, args);
    }
}
