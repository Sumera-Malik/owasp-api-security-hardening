package edu.nu.owaspapivulnlab.web;

import edu.nu.owaspapivulnlab.model.AppUser;
import edu.nu.owaspapivulnlab.repo.AppUserRepository;
import edu.nu.owaspapivulnlab.service.JwtService;
import edu.nu.owaspapivulnlab.web.dto.SignupRequest;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;

import java.util.Map;
import java.util.Optional;

/**
 * Auth endpoints with explicit class (no preview features).
 * - POST /api/auth/signup
 * - POST /api/auth/login
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController { // <-- explicit class fixes "unnamed class" compilation error

    private final AppUserRepository users;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwt;

    public AuthController(AppUserRepository users,
                          PasswordEncoder passwordEncoder,
                          JwtService jwt) {
        this.users = users;
        this.passwordEncoder = passwordEncoder;
        this.jwt = jwt;
    }

    /**
     * Signup: validates uniqueness and stores BCrypt-hashed password.
     * Returns a simple JSON message on success.
     */
    @PostMapping("/signup")
    public ResponseEntity<?> signup(@Valid @RequestBody SignupRequest req) {
        // SECURITY: check if username OR email already exists
        Optional<AppUser> existingByUser = users.findByUsername(req.getUsername());
        if (existingByUser.isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error", "username_taken"));
        }
        Optional<AppUser> existingByEmail = users.findByEmail(req.getEmail());
        if (existingByEmail.isPresent()) {
            return ResponseEntity.badRequest().body(Map.of("error", "email_taken"));
        }

        AppUser u = new AppUser();
        u.setUsername(req.getUsername());
        u.setEmail(req.getEmail());
        // BCrypt hash via PasswordEncoder bean (no plaintext storage)
        u.setPassword(passwordEncoder.encode(req.getPassword()));
        // Default role for new signups
        u.setRole("ROLE_USER");

        users.save(u);
        return ResponseEntity.ok(Map.of("message", "User registered successfully"));
    }

    /**
     * Login: verifies password and issues a short-lived JWT.
     * Body: {"username":"...", "password":"..."}
     */
    @PostMapping("/login")
    public ResponseEntity<?> login(@RequestBody Map<String, String> body) {
        String username = body.get("username");
        String password = body.get("password");

        if (username == null || password == null) {
            return ResponseEntity.badRequest().body(Map.of("error", "missing_credentials"));
        }

        AppUser u = users.findByUsername(username).orElse(null);
        if (u == null || !passwordEncoder.matches(password, u.getPassword())) {
            // Don’t reveal which part failed
            return ResponseEntity.status(401).body(Map.of("error", "invalid_credentials"));
        }

        // Issue compact JWT with subject=username and role claim
        String token = jwt.issueToken(u.getUsername(), u.getRole());
        return ResponseEntity.ok(Map.of("token", token));
    }
}
