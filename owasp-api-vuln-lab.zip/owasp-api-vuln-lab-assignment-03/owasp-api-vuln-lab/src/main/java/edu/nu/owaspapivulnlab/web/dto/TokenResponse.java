package edu.nu.owaspapivulnlab.web.dto;

// Simple DTO wrapper for JWT
public record TokenResponse(String token) {}
