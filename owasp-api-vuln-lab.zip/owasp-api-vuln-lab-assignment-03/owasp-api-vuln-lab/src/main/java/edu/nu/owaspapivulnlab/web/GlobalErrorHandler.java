package edu.nu.owaspapivulnlab.web;

import com.fasterxml.jackson.databind.exc.InvalidFormatException;
import com.fasterxml.jackson.databind.exc.UnrecognizedPropertyException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Global error handler (Task 6): turn client JSON/validation problems into HTTP 400
 * so mass-assignment attempts (unknown props like role/isAdmin) don't bubble to 500.
 */
@RestControllerAdvice
public class GlobalErrorHandler {

    /** JSON parse/bind errors → 400 */
    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<Map<String, Object>> handleBadJson(HttpMessageNotReadableException ex) {
        Map<String, Object> body = new HashMap<>();
        body.put("error", "bad_request");

        // Give precise message for unknown fields / bad formats when possible
        Throwable cause = ex.getMostSpecificCause();
        if (cause instanceof UnrecognizedPropertyException upex) {
            body.put("message", "Unrecognized field: " + upex.getPropertyName());
        } else if (cause instanceof InvalidFormatException) {
            body.put("message", "Invalid value format");
        } else {
            body.put("message", "Malformed or unsupported JSON");
        }
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    /** Bean validation (@Valid) errors → 400 with per-field messages */
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(MethodArgumentNotValidException ex) {
        Map<String, Object> body = new HashMap<>();
        body.put("error", "validation_error");

        Map<String, String> fields = new HashMap<>();
        List<FieldError> errors = ex.getBindingResult().getFieldErrors();
        for (FieldError fe : errors) {
            fields.put(fe.getField(), fe.getDefaultMessage());
        }
        body.put("fields", fields);
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }

    /** Common bad-input path → 400 (keeps server errors for real 5xx only). */
    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<Map<String, Object>> handleIllegalArg(IllegalArgumentException ex) {
        Map<String, Object> body = Map.of("error", "bad_request", "message", ex.getMessage());
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(body);
    }
}
